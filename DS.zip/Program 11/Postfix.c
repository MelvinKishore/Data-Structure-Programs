#include <stdio.h>
#include <ctype.h>
int main()
{
    char exp[100];
    int stack[100],top=-1;
    int i,op1,op2;

    printf("Enter Postfix Expression (single-digit): ");
    scanf("%s",exp);

    for(i=0;exp[i]!='\0';i++)
    {
        if (isdigit(exp[i]))
        {
            stack[++top]=exp[i]-'0';
        }
        else
        {
            op2=stack[top--];
            op1=stack[top--];

            switch (exp[i])
            {
                case '+': stack[++top]= op1 + op2; break;
                case '-': stack[++top]= op1 - op2; break;
                case '*': stack[++top]= op1 * op2; break;
                case '/': stack[++top]= op1 / op2; break;
            }
        }
    }

    printf("Result: %d\n", stack[top]);
    return 0;
}
