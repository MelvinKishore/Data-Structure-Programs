#include <stdio.h>
int main()
{
    int i,j,r1,c1;
    int a[10][10],b[10][10];
    printf("Enter Order of Matrix A & B: \n");
    scanf("%d%d",&r1,&c1);
    printf("Enter Elements Matrix A: \n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("Enter Elements Matrix of B :\n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    printf("\nMatrix Addition: \n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            printf("%d ",a[i][j]+b[i][j]);
        }
        printf("\n");

    }

    printf("\nMatrix Substraction: \n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            printf("%d ",a[i][j]-b[i][j]);
        }
        printf("\n");

    }
    return 0;
}

