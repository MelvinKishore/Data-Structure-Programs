#include <stdio.h>
int main()
{
    int i,j;
    int a[100],b[100];
    int n1,n2,n3;
    printf("Enter no of Elements in  array A: ");
    scanf("%d",&n1);
    printf("Enter Elements in array A: \n");
    for(i=0;i<n1;i++)
    {
        scanf("%d",&a[i]);
    }

    printf("Enter no of Elements in  array B: ");
    scanf("%d",&n2);
    printf("Enter Elements in array B: \n");
    for(i=0;i<n2;i++)
    {
        scanf("%d",&b[i]);
    }

    n3=n1+n2;
    int merged[n3];

    for (i=0;i<n1;i++)
    {
        merged[i]=a[i];
    }

    for (j=0;j<n2;j++)
    {
        merged[i]=b[j];
        i++;
    }

    printf("\nMerged Array: ");
    for (i=0;i<n3;i++)
    {
        printf("%d ", merged[i]);
    }
    printf("\n");
    return 0;
}
