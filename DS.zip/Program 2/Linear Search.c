#include <stdio.h>
int main()
{
    int arr[100],i,lim,num,loc,flag;
    printf("Enter no of Elements: ");
    scanf("%d",&lim);
    printf("Enter Elements: ");
    for(i=0;i<lim;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("\nElements: ");
    for(i=0;i<lim;i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");

    printf("Enter Element to Find: ");
    scanf("%d",&num);

    for(i=0;i<=lim;i++)
    {
        if(arr[i]==num)
        {
            flag=1;
            loc=i+1;
            break;
        }
    }
       if(flag==1)
    {
        printf("\nElement %d found at Position %d\n",num,loc);
    }
    else
    {
        printf("\nElement %d Not found\n",num);
    }

return 0;
}

