#include <stdio.h>
int main()
{
    int arr[100],i,j,lim,num,loc;
    int start,mid,end,flag,temp;
    printf("Enter no of Elements: ");
    scanf("%d",&lim);
    printf("Enter Elements: ");
    for(i=0;i<lim;i++)
    {
        scanf("%d",&arr[i]);
    }

    for(i=0;i<lim-1;i++)
    {
        for(j=0;j<lim-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }

    printf("\nSorted Elements: ");
    for(i=0;i<lim;i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");

    printf("Enter Element to Find: ");
    scanf("%d",&num);

    start=0;
    end=lim-1;
    while(start<=end)
    {
        mid=(start+end)/2;
        if(arr[mid]==num)
        {
            flag=1;
            loc=mid+1;
            break;
        }
        else if(arr[mid]<num)
        {
            start=mid+1;
        }
        else
        {
            end=mid-1;
        }
    }

    if(flag==1)
    {
        printf("\nElement %d found at Position %d\n",num,loc);
    }
    else
    {
        printf("\nElement %d Not found\n",num);
    }
 return 0;
}

