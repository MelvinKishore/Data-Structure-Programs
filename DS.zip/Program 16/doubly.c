#include <stdio.h>
#include <stdlib.h>

struct NODE {
    int DATA;
    struct NODE* LLINK;
    struct NODE* RLINK;
};

int main() {
    struct NODE *start = NULL, *newNode, *temp;
    int choice, val, target, found;

    while (1) {
        printf("--- Doubly Linked List Menu ---");
        printf("\n1. CREATE (Insert at End)");
        printf("\n2. SEARCH for an Element");
        printf("\n3. DISPLAY List");
        printf("\n4. EXIT");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            newNode = (struct NODE*)malloc(sizeof(struct NODE));
            printf("Enter data: ");
            scanf("%d", &val);
            newNode->DATA = val;
            newNode->RLINK = NULL;

            if (start == NULL) {
                newNode->LLINK = NULL;
                start = newNode;
            } else {
                temp = start;
                while (temp->RLINK != NULL) {
                    temp = temp->RLINK;
                }
                temp->RLINK = newNode;
                newNode->LLINK = temp;
            }
            printf("\nNode created successfully.\n");
        }
        else if (choice == 2) {
            if (start == NULL) {
                printf("\nList is empty. Nothing to search.\n");
            } else {
                printf("\nEnter element to search for: ");
                scanf("%d", &target);

                temp = start;
                found = 0;
                int pos = 1;

                while (temp != NULL) {
                    if (temp->DATA == target) {
                        printf("\nElement %d found at position %d.\n", target, pos);
                        found = 1;
                        break;
                    }
                    temp = temp->RLINK;
                    pos++;
                }

                if (!found) {
                    printf("\nElement %d not found in the list.\n", target);
                }
            }
        }
        else if (choice == 3) {
            if (start == NULL) {
                printf("\nList is empty.\n");
            } else {
                temp = start;
                printf("\nDLL Elements: NULL <- ");
                while (temp != NULL) {
                    printf("[%d] ", temp->DATA);
                    if(temp->RLINK != NULL) printf("<-> ");
                    temp = temp->RLINK;
                }
                printf("-> NULL\n");
            }
        }
        else if (choice == 4) {
            printf("Exiting...\n");
            exit(0);
        }
        else {
            printf("Invalid choice!\n");
        }
    }

    return 0;
}
