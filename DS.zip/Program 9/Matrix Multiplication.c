#include <stdio.h>
int main()
{
    int i,j,k,r1,c1;
    int a[10][10],b[10][10],c[10][10];
    printf("Enter Order of Matrix A & B: ");
    scanf("%d%d",&r1,&c1);
    printf("Enter Elements Matrix A: \n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("Enter Elements Matrix of B :\n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            scanf("%d",&b[i][j]);
            c[i][j]=0;
        }
    }

    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            for(k=0;k<r1;k++)
            {
                c[k][i]=c[k][i]+a[k][j]*b[j][i];
            }
        }
    }

    printf("\nMatrix Multiplication:\n ");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            printf("%3d",c[i][j]);
        }
    printf("\n");
    }

   return 0;
}
