#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *left, *right;
};

int main() {
    struct Node *root = NULL;
    int choice, value;

    while (1) {
        printf("\n---Binary Search Tree---");
        printf("\n1. Insert Node");
        printf("\n2. Preorder Traversal");
        printf("\n3. Inorder Traversal");
        printf("\n4. Postorder Traversal");
        printf("\n5. Exit");
        printf("\n\nEnter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Enter value: ");
            scanf("%d", &value);
            struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
            newNode->data = value;
            newNode->left = newNode->right = NULL;

            if (root == NULL) {
                root = newNode;
            } else {
                struct Node *curr = root, *parent = NULL;
                while (curr != NULL) {
                    parent = curr;
                    if (value < curr->data) curr = curr->left;
                    else curr = curr->right;
                }
                if (value < parent->data) parent->left = newNode;
                else parent->right = newNode;
            }
            printf("Inserted %d\n", value);

        } else if (choice == 2) {
            if (root == NULL) printf("Tree is empty.");
            else {
                struct Node* stack[100];
                int top = -1;
                stack[++top] = root;
                printf("Preorder: ");
                while (top >= 0) {
                    struct Node* node = stack[top--];
                    printf("%d ", node->data);
                    if (node->right) stack[++top] = node->right;
                    if (node->left) stack[++top] = node->left;
                }
            }
            printf("\n");

        } else if (choice == 3) {
            struct Node* stack[100];
            int top = -1;
            struct Node* curr = root;
            printf("Inorder: ");
            while (curr != NULL || top >= 0) {
                while (curr != NULL) {
                    stack[++top] = curr;
                    curr = curr->left;
                }
                curr = stack[top--];
                printf("%d ", curr->data);
                curr = curr->right;
            }
            printf("\n");

        } else if (choice == 4) {
            if (root == NULL) printf("Tree is empty.");
            else {
                struct Node* s1[100], *s2[100];
                int top1 = -1, top2 = -1;
                s1[++top1] = root;
                while (top1 >= 0) {
                    struct Node* node = s1[top1--];
                    s2[++top2] = node;
                    if (node->left) s1[++top1] = node->left;
                    if (node->right) s1[++top1] = node->right;
                }
                printf("Postorder: ");
                while (top2 >= 0) printf("%d ", s2[top2--]->data);
            }
            printf("\n");

        } else if (choice == 5) {
            exit(0);
        } else {
            printf("Invalid choice!\n");
        }
    }
    return 0;
}
