#include <stdio.h>
#include <stdlib.h>

struct NODE {
    int DATA;
    struct NODE *LEFT;
    struct NODE *RIGHT;
};

int main() {
    struct NODE *root = NULL, *newNode, *ptr, *parent;
    int choice, val;

    while (1) {
        printf("\n--- Binary Search Tree Menu ---");
        printf("\n1. INSERT an Element");
        printf("\n2. Display ");
        printf("\n3. EXIT");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            newNode = (struct NODE*)malloc(sizeof(struct NODE));
            printf("Enter value to insert: ");
            scanf("%d", &val);
            newNode->DATA = val;
            newNode->LEFT = NULL;
            newNode->RIGHT = NULL;

            if (root == NULL) {
                root = newNode;
                printf("Node inserted as root.\n");
            } else {
                ptr = root;
                parent = NULL;

                while (ptr != NULL) {
                    parent = ptr;
                    if (val < ptr->DATA) {
                        ptr = ptr->LEFT;
                    } else if (val > ptr->DATA) {
                        ptr = ptr->RIGHT;
                    } else {
                        printf("Duplicate value! Not inserted.\n");
                        free(newNode);
                        goto next_loop;
                    }
                }
                if (val < parent->DATA) {
                    parent->LEFT = newNode;
                } else {
                    parent->RIGHT = newNode;
                }
                printf("Node inserted.\n");
            }
        }
        else if (choice == 2) {
            if (root == NULL) {
                printf("Tree is empty.\n");
            } else {
                printf("Inorder Traversal (Sorted): ");
                struct NODE* stack[100];
                int top = -1;
                struct NODE* curr = root;

                while (curr != NULL || top != -1) {
                    while (curr != NULL) {
                        stack[++top] = curr;
                        curr = curr->LEFT;
                    }
                    curr = stack[top--];
                    printf("%d ", curr->DATA);
                    curr = curr->RIGHT;
                }
                printf("\n");
            }
        }
        else if (choice == 3) {
            exit(0);
        }
        next_loop:;
    }
    return 0;
}
