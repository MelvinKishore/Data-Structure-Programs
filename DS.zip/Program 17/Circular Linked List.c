#include <stdio.h>
#include <stdlib.h>

struct NODE {
    int DATA;
    struct NODE* LINK;
};

int main() {
    struct NODE *start = NULL, *newNode, *temp;
    int choice, val, target, found, pos;

    while (1) {
        printf("\n--- Circular Linked List Menu ---");
        printf("\n1. CREATE (Insert at End)");
        printf("\n2. SEARCH an Element");
        printf("\n3. DISPLAY List");
        printf("\n4. EXIT");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            newNode = (struct NODE*)malloc(sizeof(struct NODE));
            printf("Enter data: ");
            scanf("%d", &val);
            newNode->DATA = val;

            if (start == NULL) {
                start = newNode;
                newNode->LINK = start;
            } else {
                temp = start;
                while (temp->LINK != start) {
                    temp = temp->LINK;
                }
                temp->LINK = newNode;
                newNode->LINK = start;
            }
            printf("Node created successfully.\n\n");
        }
        else if (choice == 2) {
            if (start == NULL) {
                printf("List is empty!\n");
            } else {
                printf("Enter element to search for: ");
                scanf("%d", &target);

                temp = start;
                found = 0;
                pos = 1;

                do {
                    if (temp->DATA == target) {
                        printf("Element %d found at position %d.\n", target, pos);
                        found = 1;
                        break;
                    }
                    temp = temp->LINK;
                    pos++;
                } while (temp != start);

                if (!found) {
                    printf("Element %d not found in the list.\n", target);
                }
            }
        }
        else if (choice == 3) {
            if (start == NULL) {
                printf("List is empty.\n");
            } else {
                temp = start;
                printf("Circular List: ");
                do {
                    printf("%d -> ", temp->DATA);
                    temp = temp->LINK;
                } while (temp != start);
                printf("(Back to START)\n");
            }
        }
        else if (choice == 4) {
            printf("Exiting...\n");
            exit(0);
        }
        else {
            printf("Invalid choice!\n");
        }
    }

    return 0;
}


