#include <stdio.h>
#include <stdlib.h>

#define MAX_CAPACITY 100

int main() {
    int queue[MAX_CAPACITY];
    int front = -1, rear = -1;
    int choice, data, maxsize;

    printf("Enter size of Queue : ");
    if (scanf("%d", &maxsize) != 1 || maxsize <= 0 || maxsize > MAX_CAPACITY) {
        printf("Invalid size.\n");
        return 1;
    }

    while (1) {
        printf("\n1.ENQUEUE\n2.DEQUEUE\n3.DISPLAY\n4.EXIT\n");
        printf("\nEnter the Choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input.\n");
            break;
        }

        switch (choice) {
            case 1:
                if ((front == 0 && rear == maxsize - 1) || (rear + 1) % maxsize == front) {
                    printf("\nQueue Overflow!\n");
                } else {
                    printf("\nEnter data: ");
                    if (scanf("%d", &data) != 1) {
                        printf("Invalid input.\n");
                        while (getchar() != '\n');
                        break;
                    }
                    if (front == -1) {
                        front = rear = 0;
                    } else {
                        rear = (rear + 1) % maxsize;
                    }
                    queue[rear] = data;
                    printf("\n%d inserted.\n", data);
                }
                break;

            case 2:
                if (front == -1) {
                    printf("Queue Underflow\n");
                } else {
                    printf("\nDeleted: %d\n", queue[front]);
                    if (front == rear) {
                        front = rear = -1;
                    } else {
                        front = (front + 1) % maxsize;
                    }
                }
                break;

            case 3:
                if (front == -1) {
                    printf("Queue is empty.\n");
                } else {
                    printf("Queue elements: ");
                    int i = front;
                    while (1) {
                        printf("%d ", queue[i]);
                        if (i == rear) break;
                        i = (i + 1) % maxsize;
                    }
                    printf("\n");
                }
                break;

            case 4:
                exit(0);

            default:
                printf("Invalid choice.\n");
        }
    }
    return 0;
}
