#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *LINK;
};

int main() {
    struct Node *start = NULL, *newNode, *prev, *ptr;
    int choice, val, pos, i, n;

    printf("Enter no.of nodes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        newNode = (struct Node *)malloc(sizeof(struct Node));
        printf("Enter value for node %d: ", i + 1);
        scanf("%d", &val);
        newNode->data = val;
        newNode->LINK = NULL;

        if (start == NULL) {
            start = newNode;
        } else {
            ptr = start;
            while (ptr->LINK != NULL) {
                ptr = ptr->LINK;
            }
            ptr->LINK = newNode;
        }
        printf("Node Inserted.\n");
    }

    while (1) {
        printf("\n--- Singly Linked List ---\n");
        printf("1. Delete at Beginning\n2. Delete at End\n3. Delete at Specific Position\n4. Display\n5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            if (start == NULL) {
                printf("List is Empty\n");
            } else {
                ptr = start;
                start = start->LINK;
                free(ptr);
                printf("First Node Deleted\n");
            }
        }
        else if (choice == 2) {
            if (start == NULL) {
                printf("List is Empty\n");
            } else if (start->LINK == NULL) {
                free(start);
                start = NULL; // Important: reset start to NULL
                printf("Last Node Deleted\n");
            } else {
                ptr = start;
                prev = NULL;
                while (ptr->LINK != NULL) {
                    prev = ptr;
                    ptr = ptr->LINK;
                }
                prev->LINK = NULL; // Disconnect the last node
                free(ptr);
                printf("Last Node Deleted\n");
            }
        }
        else if (choice == 3) {
            if (start == NULL) {
                printf("List is Empty\n");
            } else {
                printf("Enter the Position to Delete: ");
                scanf("%d", &pos);
                ptr = start;
                if (pos == 1) {
                    start = start->LINK;
                    free(ptr);
                    printf("Node at Position 1 Deleted\n");
                } else {
                    prev = NULL;
                    i = 1;
                    while (i < pos && ptr != NULL) {
                        prev = ptr;
                        ptr = ptr->LINK;
                        i++;
                    }
                    if (ptr == NULL) {
                        printf("Position out of Range\n");
                    } else {
                        prev->LINK = ptr->LINK;
                        free(ptr);
                        printf("Node at Position %d deleted.\n", pos);
                    }
                }
            }
        }
        else if (choice == 4) {
            struct Node *temp = start; // Fixed: Use pointer type
            if (temp == NULL) {
                printf("List is empty.\n");
            } else {
                printf("Linked List: ");
                while (temp != NULL) {
                    printf("%d -> ", temp->data);
                    temp = temp->LINK; // Fixed: Use LINK
                }
                printf("NULL\n");
            }
        }
        else if (choice == 5) {
            printf("Exiting...\n");
            break;
        } else {
            printf("Invalid choice.\n");
        }
    }
    return 0;
}
