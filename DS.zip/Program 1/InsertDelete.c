#include <stdio.h>
int main()
{
    int i,n,pos1,pos2,ins,arr[100];
    printf("Enter no of Elements:");
    scanf("%d",&n);
    printf("Enter Elements: ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("\nElements: ");
    for(i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");

    printf("\nInsertion\n");
    printf("Enter the Position to Insert: ");
    scanf("%d",&pos1);

    printf("Enter the Element to Insert: ");
    scanf("%d",&ins);

    for(i=n;i>=pos1;i--)
    {
        arr[i]=arr[i-1];
    }
    arr[pos1-1]=ins;
    n++;

    printf("\nArray after Insertion: ");
    for(i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");

    printf("\nDeletion\n");
    printf("Enter the Position to Delete: ");
    scanf("%d",&pos2);
    for(i=pos2-1;i<n-1;i++)
    {
        arr[i]=arr[i+1];
    }
    n--;

    printf("\nArray after Insertion: ");
    for(i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }

 return 0;
}
