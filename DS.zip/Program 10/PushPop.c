#include <stdio.h>
int main()
{
    int maxsize,choice,i;
    int top=-1,flag;
    printf("Enter Maximum Size of Stack: \n");
    scanf("%d",&maxsize);
    int stack[maxsize];
    while(1)
    {
        printf("\nSelect Operation: \n");
        printf("1.Push\n2.Pop\n3.Display\n4.exit\n\n");
        scanf("%d",&choice);
        if(choice==1)
        {
            if(top==maxsize-1)
            {
                printf("\nStack Overflow\n");
            }
            else
            {
                int data;
                printf("\nEnter Elements to Push: ");
                scanf("%d",&data);
                top=top+1;
                stack[top]=data;
            }
        }
        else if(choice==2)
        {
            if(top==-1)
            {
                printf("\nStack Underflow\n");
                flag=1;
            }
            else
            {
                flag=0;
                int data=stack[top];
                top=top-1;
                printf("\nPopped Element: %d\n",data);


            }
        }
        else if(choice==3)
        {
            if(flag==1)
            {
                printf("\nStack is Empty: ");
            }
            else
            {
                printf("\nElements: ");
                for(i=top;i>=0;i--)
                {
                    printf("%d ",stack[i]);
                }
            }
        }
        else
        {
            break;
        }
    }
 return 0;
}
