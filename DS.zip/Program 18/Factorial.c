#include <stdio.h>

long int factorial(int n)
{
    if (n == 0 || n == 1)
    {
        return 1;
    }
    else
    {
        return n * factorial(n - 1);
    }

}

int main()
{
    int num;
    long int result;
    printf("Enter a positive integer: ");
    scanf("%d", &num);

    if (num < 0)
    {
        printf("Error: Factorial of a negative number is not defined.\n");
    }
    else
    {
        result = factorial(num);
        printf("Factorial of %d is %ld\n", num, result);
    }

    return 0;
}
