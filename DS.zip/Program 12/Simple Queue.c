#include <stdio.h>
int main()
{
    int maxsize,choice,i;
    int front=-1,rear=-1;
    printf("Enter Maximum Size of Queue: ");
    scanf("%d",&maxsize);
    int queue[maxsize];
    while(1)
    {
        printf("\nSelect Operation: \n");
        printf("1.ENQUEUE\n2.DEQUEUE\n3.Display\n4.exit\n\n");
        scanf("%d",&choice);
        if(choice==1)
        {
            if(rear==maxsize-1)
            {
                printf("\nQueue Overflow\n");
            }
            else
            {
                int data;
                printf("\nEnter Elements to Insert: ");
                scanf("%d",&data);
                if(front==-1)
                {
                    front=0;
                }
                rear=rear+1;
                queue[rear]=data;
            }
        }
        else if(choice==2)
        {
            if(rear==-1||front>rear)
            {
                printf("\nQueue Underflow\n");
            }
            else
            {
                int data=queue[front];
                front=front+1;
                if(front>rear)
                {
                    front=rear=-1;
                }
                printf("\nPopped Element: %d\n",data);

            }
        }
        else if(choice==3)
        {
            if(front == -1)
            {
                printf("Queue is empty.\n");
            }
            else
            {
                printf("\nElements: ");
                for(i=front;i<=rear;i++)
                {
                    printf("%d ",queue[i]);
                }
                printf("\n");
            }

        }
        else if(choice==4)
        {
            break;
        }
        else
        {
            printf("Invalid Input\n");
        }
    }
    return 0;
}
