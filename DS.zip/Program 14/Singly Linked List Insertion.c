#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

int main() {
    struct Node *head = NULL, *newNode, *temp;
    int choice, data, pos, count;

    while (1) {
        printf("\nSingly Linked List\n");
        printf("1. Insert at Beginning\n");
        printf("2. Insert at End\n");
        printf("3. Insert at Specific Position\n");
        printf("4. Display\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input.\n");
            return 1;
        }

        if (choice == 1) {
            newNode = (struct Node *)malloc(sizeof(struct Node));
            if (!newNode) { printf("Memory allocation failed.\n"); continue; }
            printf("Enter data: ");
            scanf("%d", &data);
            newNode->data = data;
            newNode->next = head;
            head = newNode;
            printf("\nInserted %d at beginning.\n",data);

        } else if (choice == 2) {
            newNode = (struct Node *)malloc(sizeof(struct Node));
            if (!newNode) { printf("Memory allocation failed.\n"); continue; }
            printf("Enter data: ");
            scanf("%d", &data);
            newNode->data = data;
            newNode->next = NULL;
            if (head == NULL) {
                head = newNode;
            } else {
                temp = head;
                while (temp->next != NULL) {
                    temp = temp->next;
                }
                temp->next = newNode;
            }
            printf("\nInserted at end.\n");

        } else if (choice == 3) {
            printf("Enter position: ");
            scanf("%d", &pos);
            if (pos < 1) {
                printf("Invalid position.\n");
                continue;
            }
            newNode = (struct Node *)malloc(sizeof(struct Node));
            if (!newNode) { printf("Memory allocation failed.\n"); continue; }
            printf("Enter data: ");
            scanf("%d", &data);
            newNode->data = data;

            if (pos == 1) {
                newNode->next = head;
                head = newNode;
            } else {
                temp = head;
                count = 1;
                while (temp != NULL && count < pos - 1) {
                    temp = temp->next;
                    count++;
                }
                if (temp == NULL) {
                    printf("Position out of range.\n");
                    free(newNode);
                    continue;
                }
                newNode->next = temp->next;
                temp->next = newNode;
            }
            printf("\nInserted %d at position %d.\n", data, pos);

        } else if (choice == 4) {
            temp = head;
            if (temp == NULL) {
                printf("List is empty.\n");
            } else {
                printf("Linked List: ");
                while (temp != NULL) {
                    printf("%d -> ", temp->data);
                    temp = temp->next;
                }
                printf("NULL\n");
            }

        } else if (choice == 5) {
            printf("Exiting...\n");
            break;

        } else {
            printf("Invalid choice.\n");
        }
    }
    return 0;
}

