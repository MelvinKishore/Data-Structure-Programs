#include <stdio.h>
int main()
{
    int arr[100],n,i,j,temp,min;
    printf("Enter number of Elements: ");
    scanf("%d",&n);
    printf("Enter Elements: ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }

    for(i=0;i<n-1;i++)
    {
        min=i;
        for(j=i+1;j<n;j++)
        {
            if(arr[j]<arr[min])
            {
                min=j;
            }
        }

        temp=arr[min];
        arr[min]=arr[i];
        arr[i]=temp;
    }

    printf("Sorted Array: ");
    for(i=0;i<n;i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
  return 0;
}


//last opened 22-12-2025 @06:20
